#!/bin/bash
# Driving-force scan (added after the pinning observation). Same build, IC and
# parameters as run_all.sh; only dfBias and tEnd differ. tEnd is chosen so that
# the GB stays below z = 48 even at the continuum-predicted velocity.
set -e
cd "$(dirname "$0")"
exec 9> .run.lock; flock 9          # wait until run_all.sh has finished
for spec in "df0.0375 0.0375 250" "df0.075 0.075 190" "df0.1 0.1 140"; do
  set -- $spec; name=$1; df=$2; te=$3; d=runs/$name; mkdir -p $d
  [ -f $d/done ] && continue
  cmd="../../src/pf_mig_32 initIn=../../ic/gb_z20.bin bGB=2.0 dfBias=$df gbOnly=1 tEnd=$te outDt=0.1 snapDt=10 outDir=."
  echo "$cmd" > $d/run.sh
  (cd $d && $cmd > run.log 2>&1) && touch $d/done
  echo "$(date '+%T') $name done" >> progress.log
done
echo SCAN_DONE >> progress.log
