#!/bin/bash
# GB-migration experiment (bubble-free). Resumable, single instance.
# Build : g++ -O3 -march=native -fopenmp -std=c++17 -DGRID_NX=32 -DGRID_NY=32 -DGRID_NZ=64 \
#             src/phasefield_gb_migration3d.cpp -o src/pf_mig_32
# Fixed : bGB=2.0 and all other parameters at the code defaults/baseline
#         (A0=4 bS=1 j=2 jGB=2 LGB=1 Ms=0.05 Mgb=0.5 Mb=5 safety=0.5 dtMax=1e-3), outDt=0.1
set -e
cd "$(dirname "$0")"
exec 9> .run.lock; flock -n 9 || { echo "already running"; exit 1; }
[ -x src/pf_mig_32 ] || g++ -O3 -march=native -fopenmp -std=c++17 -DGRID_NX=32 -DGRID_NY=32 -DGRID_NZ=64 src/phasefield_gb_migration3d.cpp -o src/pf_mig_32
[ -f ic/gb_z20.bin ]      || python3 make_ic.py out=ic/gb_z20.bin
[ -f ic/gb_z20_amp1.bin ] || python3 make_ic.py out=ic/gb_z20_amp1.bin amp=1.0
TEND=${TEND:-250}
for spec in "df0.05 0.05 gb_z20" "df0 0 gb_z20" "df0.025 0.025 gb_z20" "df0.05_pert 0.05 gb_z20_amp1"; do
  set -- $spec; name=$1; df=$2; ic=$3; d=runs/$name; mkdir -p $d
  [ -f $d/done ] && continue
  cmd="../../src/pf_mig_32 initIn=../../ic/$ic.bin bGB=2.0 dfBias=$df gbOnly=1 tEnd=$TEND outDt=0.1 snapDt=10 outDir=."
  echo "$cmd" > $d/run.sh
  (cd $d && $cmd > run.log 2>&1) && touch $d/done
  echo "$(date '+%T') $name done" >> progress.log
done
echo ALL_DONE >> progress.log
