"""
analyse.py - GB-migration experiment: trajectory, velocity history, validation.
Reads runs/<case>/gb_position.csv (written by the simulation itself) and the
grain snapshots; writes results/ (CSV + figures). Usage: python3 analyse.py
"""
import glob
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

OUT = "results"; os.makedirs(OUT, exist_ok=True)
NX, NY, NZ = 32, 32, 64
A, N = NX * NY, NX * NY * NZ
L, JGB = 1.0, 2.0                       # LGB, jGB (code defaults used in every run)
CASES = [("df0", 0.0), ("df0.025", 0.025), ("df0.0375", 0.0375), ("df0.05", 0.05), ("df0.075", 0.075), ("df0.1", 0.1), ("df0.05_pert", 0.05)]
COL = {"df0": "#555555", "df0.025": "#8c564b", "df0.0375": "#8e44ad", "df0.05": "#c0392b", "df0.075": "#1f4e9c", "df0.1": "#27ae60", "df0.05_pert": "#e09f3e"}
LAB = {"df0": "Δf = 0 (control)", "df0.025": "Δf = 0.025", "df0.0375": "Δf = 0.0375", "df0.05": "Δf = 0.05", "df0.075": "Δf = 0.075", "df0.1": "Δf = 0.1",
       "df0.05_pert": "Δf = 0.05, initial 1-cell GB ripple"}
Z0, ZTOP, ZLIM = 20.0, NZ - 1, 48.0      # initial GB, top wall cell, end of the measurement interval

D = {}
for name, df in CASES:
    fn = f"runs/{name}/gb_position.csv"
    if os.path.exists(fn):
        D[name] = pd.read_csv(fn)
D = {k: v for k, v in D.items() if v.time.iloc[-1] >= 40}   # skip runs still in progress
print("runs analysed:", list(D))

# ---------------- relaxation time from the control (interface structure) ----
ctrl = D.get("df0")
t_relax = np.nan
if ctrl is not None:
    wfin = ctrl.gb_width_int16n1n2n2.iloc[-1]
    ok = np.abs(ctrl.gb_width_int16n1n2n2 / wfin - 1) < 0.005
    # first time after which the width stays within 0.5 % of its final value
    bad = np.flatnonzero(~ok.to_numpy())
    t_relax = float(ctrl.time.iloc[bad[-1] + 1]) if len(bad) else 0.0
    gamma = (ctrl.free_energy.iloc[-1] - (-1.0) * N) / A   # both grains have f = -1 per cell at dfBias = 0
else:
    gamma = np.nan
print(f"control: relaxation (width within 0.5 % of final) by t = {t_relax}; gamma_GB = {gamma:.5f}")

rows, hist = [], []
for name, df in CASES:
    if name not in D:
        continue
    m = D[name]; t, z = m.time.to_numpy(), m.gb_z_mean.to_numpy()
    # velocity history: sliding least-squares slope over a 5-time-unit window
    win = 50
    for i in range(0, len(t) - win, 10):
        p = np.polyfit(t[i:i + win + 1], z[i:i + win + 1], 1)
        hist.append(dict(case=name, df_bias=df, t_mid=0.5 * (t[i] + t[i + win]), v=p[0],
                         z_mid=np.mean(z[i:i + win + 1])))
    # linear fit only over the post-relaxation interval, before the GB nears the wall
    t_fit0 = max(t_relax if np.isfinite(t_relax) else 0.0, 10.0)
    sel = (t >= t_fit0) & (z <= ZLIM)
    p, cov = np.polyfit(t[sel], z[sel], 1, cov=True)
    res = z[sel] - np.polyval(p, t[sel])
    r2 = 1 - (res ** 2).sum() / ((z[sel] - z[sel].mean()) ** 2).sum() if df else np.nan
    # energy consistency: dF/dt should equal -df * A * v
    pf = np.polyfit(t[sel], m.free_energy.to_numpy()[sel], 1)
    v_pred = L * JGB * df / gamma if np.isfinite(gamma) else np.nan
    rows.append(dict(case=name, df_bias=df, z_initial=z[0], z_at_t_relax=float(np.interp(t_fit0, t, z)),
                     z_final=z[-1], t_final=t[-1], dz_total=z[-1] - z[0],
                     fit_interval=f"[{t_fit0:g}, {t[sel].max():g}]", v_fit=p[0], v_fit_se=np.sqrt(cov[0, 0]),
                     fit_r2=r2, fit_resid_max=np.abs(res).max(), v_pred_sharp_interface=v_pred,
                     v_fit_over_pred=p[0] / v_pred if df else np.nan,
                     dFdt=pf[0], minus_df_A_v=-df * A * p[0],
                     max_std=m.gb_z_std.max(), std_final=m.gb_z_std.iloc[-1],
                     min_zmin=m.gb_z_min.min(), max_zmax=m.gb_z_max.max(),
                     cols_multi_max=int(m.columns_multiple_crossings.max()),
                     cols_none_max=int(m.columns_no_crossing.max()),
                     free_energy_increases=int((np.diff(m.free_energy) > 1e-9 * np.abs(m.free_energy[:-1])).sum()),
                     max_abs_c=float(max(abs(m.c_min.min()), abs(m.c_max.max()))),
                     gas_total_max=float(m.gas_total.abs().max()),
                     n_range=f"[{m.n_min.min():.3g}, {m.n_max.max():.3g}]", nonfinite=int(m.nonfinite.max()),
                     dt_mean=float(m.dt[m.dt > 0].mean()),
                     gap_to_top_wall_final=ZTOP - z[-1]))
S = pd.DataFrame(rows); S.to_csv(f"{OUT}/velocity_summary.csv", index=False)
H = pd.DataFrame(hist); H.to_csv(f"{OUT}/velocity_history.csv", index=False)
allc = pd.concat([D[n].assign(case=n) for n, _ in CASES if n in D])
allc["dz_from_initial"] = allc.gb_z_mean - allc.groupby("case").gb_z_mean.transform("first")
allc.to_csv(f"{OUT}/gb_position_all_runs.csv", index=False)

# ---------------- planarity: decay of the ripple ----
pert = None
if "df0.05_pert" in D:
    m = D["df0.05_pert"]; amp = np.sqrt(2) * m.gb_z_std          # sinusoid: std = amp / sqrt(2)
    sel = (amp > 1e-3) & (amp < 0.8 * amp.iloc[0])
    k = 2 * np.pi / NX
    rate = -np.polyfit(m.time[sel], np.log(amp[sel]), 1)[0] if sel.sum() > 5 else np.nan
    pert = dict(initial_amplitude=float(amp.iloc[0]), decay_rate_fit=float(rate),
                decay_rate_pred_LjGBk2=L * JGB * k ** 2, amplitude_final=float(amp.iloc[-1]))

# ---------------- interface profile: control vs moving GB ----
def profiles(case):
    s = pd.read_csv(f"runs/{case}/snapshots.csv"); out = []
    for r in s.itertuples():
        g = np.fromfile(f"runs/{case}/{r.grains_file}", dtype=np.float32).reshape(2, NZ, NY, NX)
        out.append((r.time_dimensionless, g[0][:, 0, 0].astype(float), g[1][:, 0, 0].astype(float)))
    return out


def width_10_90(z, n):
    lo, hi = np.interp(0.1, n, z), np.interp(0.9, n, z)   # n1 increases with z
    return hi - lo


prof = {c: profiles(c) for c in ("df0", "df0.05") if c in D}
pw = []
for c, P in prof.items():
    for t, a, b in P:
        zz = np.arange(NZ)
        pw.append(dict(case=c, t=t, width_10_90_n1=width_10_90(zz, a), min_s=float((a ** 2 + b ** 2).min()),
                       n1_at_top=float(a[-1]), n2_at_top=float(b[-1]), n2_at_bottom=float(b[0])))
PW = pd.DataFrame(pw); PW.to_csv(f"{OUT}/profile_checks.csv", index=False)

json.dump(dict(t_relax=t_relax, gamma_GB_from_control=gamma, ripple=pert), open(f"{OUT}/summary.json", "w"), indent=1, default=float)

# ---------------- figures ----
fig, ax = plt.subplots(figsize=(8, 5.6))
for name, df in CASES:
    if name not in D:
        continue
    m = D[name]
    ax.plot(m.time, m.gb_z_mean, color=COL[name], lw=2 if name != "df0.05_pert" else 1.4,
            ls="-" if name != "df0.05_pert" else "--", label=LAB[name])
    if m.gb_z_std.max() > 1e-3:
        ax.fill_between(m.time, m.gb_z_min, m.gb_z_max, color=COL[name], alpha=0.2, lw=0, label=LAB[name] + ": min–max")
ax.axhline(Z0, color="k", lw=0.8, ls=":"); ax.text(2, Z0 - 1.4, "initial GB, z = 20", fontsize=8)
ax.axhline(ZTOP, color="k", lw=1.2); ax.text(130, ZTOP - 2.2, "top wall (z = 63, no-flux)", fontsize=8)
ax.axhline(ZLIM, color="grey", lw=0.8, ls="--"); ax.text(130, ZLIM + 0.6, "end of measurement interval (z = 48)", fontsize=7, color="grey")
ax.annotate("", xy=(0.93, 0.62), xytext=(0.93, 0.32), xycoords="axes fraction",
            arrowprops=dict(arrowstyle="->", lw=2, color="#c0392b"))
ax.text(0.80, 0.25, "migration into grain I\n(grain II grows)", transform=ax.transAxes, fontsize=8, color="#c0392b", ha="center")
ax.text(0.02, 0.03, "below: grain II (n2 = 1, favoured)   above: grain I (n1 = 1)", transform=ax.transAxes, fontsize=8)
ax.set_xlabel("Time (dimensionless)"); ax.set_ylabel("Grain-boundary position  z$_{GB}$ (cells, n1 = n2 crossing)")
ax.set_ylim(0, NZ + 1); ax.grid(alpha=0.3); ax.legend(fontsize=7, loc="upper left", bbox_to_anchor=(0.0, 0.93))
ax.set_title("Grain-boundary position vs time (32×32×64, bubble-free, bGB = 2.0)", fontsize=10)
fig.tight_layout(); fig.savefig(f"{OUT}/gb_position_vs_time.png", dpi=200)

fig, axs = plt.subplots(1, 3, figsize=(16, 4.6))
for name, df in CASES:
    if name not in D:
        continue
    m = D[name]
    axs[0].plot(m.time, m.gb_z_mean - m.gb_z_mean.iloc[0], color=COL[name], label=LAB[name])
    h = H[H.case == name]; axs[1].plot(h.t_mid, h.v, color=COL[name], label=LAB[name])
    r = S[S.case == name].iloc[0]
    if df:
        axs[1].axhline(r.v_pred_sharp_interface, color=COL[name], ls=":", lw=1)
axs[0].set_ylabel("Δz$_{GB}$(t) = z$_{GB}$(t) − z$_{GB}$(0)"); axs[0].set_title("Displacement", fontsize=10)
axs[1].set_ylabel("v$_{GB}$ (cells / time), 5-unit sliding fit"); axs[1].set_title("Velocity history (dotted: sharp-interface prediction L·jGB·Δf/γ)", fontsize=9)
if ctrl is not None:
    axs[2].plot(ctrl.time, ctrl.gb_width_int16n1n2n2, color=COL["df0"], label="control: ∫16 n1²n2² dz")
    axs[2].plot(D["df0.05"].time, D["df0.05"].gb_width_int16n1n2n2, color=COL["df0.05"], label="Δf = 0.05")
    axs[2].axvline(t_relax, color="k", ls=":", lw=0.8); axs[2].set_title(f"Interface relaxation (control settles by t ≈ {t_relax:g})", fontsize=10)
    axs[2].set_ylabel("GB width integral (cells)")
for a in axs:
    a.set_xlabel("Time (dimensionless)"); a.grid(alpha=0.3); a.legend(fontsize=7)
fig.tight_layout(); fig.savefig(f"{OUT}/displacement_velocity_relaxation.png", dpi=180)

if prof:
    fig, ax = plt.subplots(figsize=(7, 4.6))
    for c, P in prof.items():
        m = D[c]
        for t, a, b in P[1::6]:
            zc = float(np.interp(t, m.time, m.gb_z_mean))
            ax.plot(np.arange(NZ) - zc, a, color=COL[c], lw=1, alpha=0.8)
            ax.plot(np.arange(NZ) - zc, b, color=COL[c], lw=1, alpha=0.8, ls="--")
    ax.set_xlim(-8, 8); ax.set_xlabel("z − z$_{GB}$(t)  (cells)"); ax.set_ylabel("order parameter")
    ax.set_title("GB profiles, re-centred (solid n1, dashed n2): grey control, red Δf = 0.05\n(snapshots every 60 time units)", fontsize=9)
    ax.grid(alpha=0.3); fig.tight_layout(); fig.savefig(f"{OUT}/gb_profiles.png", dpi=180)

pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)
print(S.T.to_string())
print(json.dumps(dict(t_relax=t_relax, gamma=gamma, ripple=pert), indent=1, default=float))
print(PW.groupby("case").agg(width_min=("width_10_90_n1", "min"), width_max=("width_10_90_n1", "max"),
                             min_s_min=("min_s", "min"), min_s_max=("min_s", "max"), n2_top_max=("n2_at_top", "max")).round(5))

# ---------------- v vs driving force ----
sc = S[S.case != "df0.05_pert"].sort_values("df_bias")
if len(sc) > 1:
    fig, ax = plt.subplots(figsize=(6.4, 4.8))
    xs = np.linspace(0, sc.df_bias.max() * 1.05, 50)
    ax.plot(xs, L * JGB * xs / gamma, "k--", lw=1, label=f"continuum prediction L·jGB·Δf/γ (γ = {gamma:.4f}, from control)")
    ax.errorbar(sc.df_bias, sc.v_fit, yerr=sc.v_fit_se, fmt="o", color="#c0392b", mec="k", capsize=3,
                label="measured mean velocity (post-relaxation linear fit)")
    for r in sc.itertuples():
        ax.annotate(f"{r.v_fit:.4f}", (r.df_bias, r.v_fit), textcoords="offset points", xytext=(6, -10), fontsize=7)
    ax.set_xlabel("Bulk free-energy difference Δf = f$_I$ − f$_{II}$"); ax.set_ylabel("GB velocity (cells / time)")
    ax.set_title("Migration velocity vs driving force (32×32×64, bGB = 2.0)", fontsize=10)
    ax.grid(alpha=0.3); ax.legend(fontsize=7); fig.tight_layout(); fig.savefig(f"{OUT}/velocity_vs_driving_force.png", dpi=200)
