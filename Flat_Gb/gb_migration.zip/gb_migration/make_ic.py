"""
make_ic.py - bubble-free two-grain initial condition for the GB-migration
experiment, written in the simulation's own binary IC format (PFGBIC01).

  grid      : NX x NY x NZ (default 32 x 32 x 64), cell-centre index z = 0..NZ-1
  c         : 0 everywhere (pure-grain state; no gas, no bubbles, no noise)
  grain II  : n2 = 1 below the GB  (the energetically favoured grain, dfBias > 0)
  grain I   : n1 = 1 above the GB
  profile   : n1 = 0.5 (1 + tanh((z - z0)/w)),  n2 = 0.5 (1 - tanh((z - z0)/w)),
              w = 1.5 cells, i.e. the same tanh profile and width as the original
              generator (Simulation::generate), only centred at z0 instead of 31.5
              and with the grains in swapped positions.
  z0        : 20.0 (n1 = n2 exactly at cell index 20)
  amp       : optional amplitude of a sinusoidal GB-height perturbation
              z0 + amp*cos(2 pi x/NX) (default 0 = perfectly planar)

Usage: python3 make_ic.py out=ic/gb_z20.bin [z0=20 w=1.5 amp=0 nx=32 ny=32 nz=64]
"""
import struct
import sys

import numpy as np

a = dict(s.split("=") for s in sys.argv[1:])
nx, ny, nz = int(a.get("nx", 32)), int(a.get("ny", 32)), int(a.get("nz", 64))
z0, w, amp = float(a.get("z0", 20.0)), float(a.get("w", 1.5)), float(a.get("amp", 0.0))
out = a.get("out", "ic/gb_z20.bin")

z = np.arange(nz, dtype=float)[:, None, None]
x = np.arange(nx, dtype=float)[None, None, :]
zgb = z0 + amp * np.cos(2 * np.pi * x / nx) + 0 * np.arange(ny)[None, :, None]
n1 = 0.5 * (1.0 + np.tanh((z - zgb) / w))           # grain I above
n2 = 0.5 * (1.0 - np.tanh((z - zgb) / w))           # grain II below
c = np.zeros((nz, ny, nx))
n1 = np.broadcast_to(n1, (nz, ny, nx)).astype(np.float64)
n2 = np.broadcast_to(n2, (nz, ny, nx)).astype(np.float64)

with open(out, "wb") as f:
    f.write(b"PFGBIC01")
    f.write(struct.pack("3i", nx, ny, nz))
    f.write(struct.pack("4d", 0.0, 0.0, 0.0, 0.0))   # r0, cInit, noise, seed (unused: no bubbles)
    f.write(struct.pack("i", 0))                      # number of bubble centres = 0
    f.write(np.ascontiguousarray(c).tobytes())
    f.write(np.ascontiguousarray(n1).tobytes())
    f.write(np.ascontiguousarray(n2).tobytes())
print(f"wrote {out}: {nx}x{ny}x{nz}, z0={z0}, w={w}, amp={amp}; "
      f"n1 at z=0: {n1[0,0,0]:.3e}, n2 at z={nz-1}: {n2[-1,0,0]:.3e}; max|c|={np.abs(c).max()}")
