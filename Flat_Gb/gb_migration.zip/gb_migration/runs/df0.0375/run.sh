../../src/pf_mig_32 initIn=../../ic/gb_z20.bin bGB=2.0 dfBias=0.0375 gbOnly=1 tEnd=250 outDt=0.1 snapDt=10 outDir=.
