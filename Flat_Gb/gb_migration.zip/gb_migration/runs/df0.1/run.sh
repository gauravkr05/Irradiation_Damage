../../src/pf_mig_32 initIn=../../ic/gb_z20.bin bGB=2.0 dfBias=0.1 gbOnly=1 tEnd=140 outDt=0.1 snapDt=10 outDir=.
../../src/pf_mig_32 restartIn=checkpoint.bin bGB=2.0 dfBias=0.1 gbOnly=1 tEnd=140 outDt=0.1 snapDt=10 outDir=.
